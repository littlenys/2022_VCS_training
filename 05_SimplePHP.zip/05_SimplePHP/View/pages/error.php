<?php
  echo 'Có lỗi xảy ra!';
?>
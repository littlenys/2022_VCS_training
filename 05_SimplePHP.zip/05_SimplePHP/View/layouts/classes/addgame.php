
<!DOCTYPE html>
<html>
    <head>
        <title>Tạo trò chơi</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <br>
        <h1>Tạo trò chơi</h1>
        <form method="post" enctype="multipart/form-data">
                <input type="file" name="file" id="file"  accept=".txt">
                <br>
                <label>Gợi ý</label>
                <br>
                <input type="text" name="goiy" value="Đây là một tác phẩm của ..."  />
                <br>
                <input type="submit" value="Tạo trò chơi" name="fileupload">
        </form>
    </body>
</html>
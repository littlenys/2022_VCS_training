
<!-- TODO remove this. 'get_list','addstudent','editstudent','myinfo','profile' 
'home','addassignment','getlistassignment','viewassignment','getlistsubmission','addgame','getlistgame'
-->

<html>
<head>
        <title>Thong tin ca nhan</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
<body>
    <br>
<div align="center" class="mt-5">
<a class="mr-5" href="?controller=pages&action=myinfo" rel="nofollow" >
    <img width="150px"  src="../05_SimplePHP/Public/image/myinfo.png" alt="profile">
</a>
<a href="?controller=pages&action=get_list" rel="nofollow">
    <img width="150px"  src="../05_SimplePHP/Public/image/getliststudent.png" alt="get_list_student">
</a>
</div>
<div align="center" class="mt-5">
<a class="mr-5" href="?controller=classes&action=getlistassignment" rel="nofollow">
    <img width="150px"  src="../05_SimplePHP/Public/image/getlistassignment.png" alt="getlistassignment">
</a>
</div>
<div align="center" class="mt-5">
<a href="?controller=classes&action=getlistgame" rel="nofollow">
    <img width="150px"  src="../05_SimplePHP/Public/image/getlistgame.png" alt="getlistgame">
</a>
</div>
</body>
</html>
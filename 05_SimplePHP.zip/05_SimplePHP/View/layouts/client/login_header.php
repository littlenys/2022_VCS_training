<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="../05_SimplePHP/Public/style/login_header.css">
</head>

<body>
    <div class="form">
        <a href="http://localhost/05_SimplePHP/index.php?controller=pages&action=signup" class="csw-btn-button" rel="nofollow" target="_blank">
            <div class="button">
                <h1>Sign Up</h1>
            </div>
        </a>
        <br>
        <a href="http://localhost/05_SimplePHP/index.php?controller=pages&action=login" class="csw-btn-button" rel="nofollow" target="_blank">
            <div class="button">
                <h1>Login</h1>
            </div>
    </div>
    </a>
</body>

</html>
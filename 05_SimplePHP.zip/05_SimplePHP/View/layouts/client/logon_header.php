<html>
<a href="?controller=pages&action=logout" class="csw-btn-button" rel="nofollow">
    <h2>
        Logout
    </h2>
</a>

</html>
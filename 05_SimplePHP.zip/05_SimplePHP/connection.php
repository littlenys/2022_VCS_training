<?php
	require('Model/Database.php');
	$db = new Database;
	$db->connect();
	/*Xử lý các request*/

	/*$db->closeDatabase();*/

<?php
include_once("E_Student.php");

class Model_Student
{
    public function __construct()
    {}

    public function getAllStudent()
    {
        
    }
}

?>